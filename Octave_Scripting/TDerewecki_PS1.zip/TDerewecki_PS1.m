% Taras Derewecki
% CMPSC 455
% Dr. Justin Keller
% Problem Set 1

%----------------------------------------------------------------

% Problems:
%   Page 20 - 21:
%     1.3.1A - 1.3.1E
%     1.3.3A, 1.3.3G, 1.3.H
%     1.3.7
%     1.3.8A
%     1.3.12

%   Page 28 - 29:
%     1.4.1A
%     1.4.3
%     1.4.7
%     1.4.10A, 1.4.10B
%     1.4.11A, 1.4.11B, 1.4.11C

%----------------------------------------------------------------

format long, clear;

% 1.3.1A
printf('1.3.1A \n');
absoluteError = abs(pi - 22/7);
relativeError = absoluteError / abs(pi);
printf('Absolute Error: %f', absoluteError);
printf('\n');
printf('Relative Error: %f', relativeError);
printf('\n\n');


% 1.3.1B
printf('1.3.1B \n');
absoluteError = abs(pi - 3.1416);
relativeError = absoluteError / abs(pi);
printf('Absolute Error: %f', absoluteError);
printf('\n');
printf('Relative Error: %f', relativeError);
printf('\n\n');

% 1.3.1C
printf('1.3.1C \n');
absoluteError = abs(e - 2.718);
relativeError = absoluteError / abs(e);
printf('Absolute Error: %f', absoluteError);
printf('\n');
printf('Relative Error: %f', relativeError);
printf('\n\n');

% 1.3.1D
printf('1.3.1D \n');
absoluteError = abs(sqrt(2) - 1.414);
relativeError = absoluteError / abs(sqrt(2));
printf('Absolute Error: %f', absoluteError);
printf('\n');
printf('Relative Error: %f', relativeError);
printf('\n\n');

% 1.3.1E
printf('1.3.1E \n');
absoluteError = abs((e)^10 - 22000);
relativeError = absoluteError / abs((e)^10);
printf('Absolute Error: %f', absoluteError);
printf('\n');
printf('Relative Error: %f', relativeError);
printf('\n\n');


%1.3.3A
printf('1.3.3A \n');
n1 = chip(1,3,133);
n2 = chip(1,3,0.921);
answer = chip(1, 3, n1 + n2);
absoluteError = abs((n1 + n2) - answer);
relativeError = absoluteError / abs(n1 + n2);
printf('Absolute Error: %f', absoluteError);
printf('\n');
printf('Relative Error: %f', relativeError);
printf('\n\n');


%1.3.3G
printf('1.3.3G \n');
n1 = chip(1,3,2/9);
n2 = chip(1,3,9/7);
ans = chip(1,3,n1*n2);

%abs error
exact = 2/7
absoluteError = abs(exact - ans);
relativeError = abs(exact - ans)/abs(exact);
printf('Absolute Error: %f', absoluteError);
printf('\n');
printf('Relative Error: %f', relativeError);
printf('\n\n'); 


%1.3.3H
printf('1.3.3H \n');
n1 = pi;
n2 = 22/7;
n3 = 1/17;
ans = chip(1,3,abs((n1 - n2)/n3));

%abs error
exact = 0.021496
absoluteError = abs(exact - ans);
relativeError = abs(exact - ans)/abs(exact);
printf('Absolute Error: %f', absoluteError);
printf('\n');
printf('Relative Error: %f', relativeError);
printf('\n\n'); 


%1.3.7A
printf('1.3.7A \n');
ans = 4*(((1/2)-(1/3)*(1/2)^3 +(1/5)*(1/2)^5)+((1/3) - (1/3)*(1/3)^3 +(1/5)*(1/3)^5));

%abs error
exact = 4*(atan(0.5) + atan(1/3))
absoluteError = abs(exact - ans);
relativeError = absoluteError/abs(exact);
printf('Absolute Error: %f', absoluteError);
printf('\n');
printf('Relative Error: %f', relativeError);
printf('\n\n'); 


%1.3.7B
printf('1.3.7B \n');
ans = (16*((1/5)-(1/3)*(1/5)^3 +(1/5)*(1/5)^5)) - (4*((1/239) - (1/3)*(1/239)^3 +(1/5)*(1/239)^5));

%abs error
exact = (16*(atan(1/5))) - (4*atan(1/239))
absoluteError = abs(exact - ans);
relativeError = absoluteError/abs(exact);
printf('Absolute Error: %f', absoluteError);
printf('\n');
printf('Relative Error: %f', relativeError);
printf('\n\n');


%1.3.8A
printf('1.3.8A \n');
a = 1.130;
b = -6.990;
c = 8.110;
d = 12.20;
e = 14.20;
f = -0.1370;
m = chip(1,4,c/a);
mb = chip(1,4,m*b);
me = chip(1,4,m*e);
d1 = chip(1,4,d - mb);
f1 = chip(1,4,f-me);
y = chip(1,4,f1/d1);
by = chip(1,4,b*y);
lol = chip(1,4,e-by);
x = chip(1,4,lol/a);

printf('X = %f', x);
printf('\n');
printf('Y = %f', y);
printf('\n\n'); 


%1.3.12A
printf('1.3.12A \n');
answerOne = chip(1,5,124.031);
answerTwo = chip(0,5,124.031);
printf('%f', answerOne);
printf('\n');
printf('%f', answerTwo);
printf('\n\n');


%1.3.12B
printf('1.3.12B \n');
answerOne = chip(1,5,124.036);
answerTwo = chip(0,5,124.036);
printf('%f', answerOne);
printf('\n');
printf('%f', answerTwo);
printf('\n\n');


%1.3.12C
printf('1.3.12C \n');
answerOne = chip(1,2,-0.00653);
answerTwo = chip(0,2,-0.00653);
printf('%f', answerOne);
printf('\n');
printf('%f', answerTwo);
printf('\n\n');


%1.3.12D
printf('1.3.12D \n');
answerOne = chip(1,2,-0.00656);
answerTwo = chip(0,2,-0.00656);
printf('%f', answerOne);
printf('\n');
printf('%f', answerTwo);
printf('\n\n');


%1.4.1A
printf('1.4.1A \n');
a = chip(1,4,1/3);
b = chip(1,4,-123/4);
c = chip(1,4,1/6);
x2 = (2*(c)) / (-b + sqrt(b^2-(4*a*c)));
x1q = ((123/4) + sqrt((-123/4)^2 - 4*(1/3)*(1/6))) / (2*(1/3));
x2q = ((123/4) - sqrt((-123/4)^2 - 4*(1/3)*(1/6))) / (2*(1/3));

r = chip(1,4,4*chip(1,4,a));
r = chip(1,4,r * chip(1,4,c));
r = chip(1,4,chip(1,4,chip(1,4,b)^2)-r);
r = chip(1,4, -1*chip(1,4,b)+chip(1,4,sqrt(r)));
r = chip(1,4,r / chip(1,4,2*chip(1,4,a)));
x1 = r;

answerOne = chip(1,4,x1);
printf('X1 = %f', answerOne);
printf('\n');
absError = abs(x1q - answerOne);
relError = abs(absError) / abs(x1q);
printf('Absolute Error for X1: %f', absError);
printf('\n');
printf('Relative Error for X1: %f', relError);
printf('\n');

answerTwo = chip(1,4,x2); %approx
printf('X2 = %f', answerTwo);
printf('\n');
absError = abs((x2q - answerTwo));
relError = abs((absError)) / abs(x2);
printf('Absolute Error for X2: %f', absError);
printf('\n');
printf('Relative Error for X2: %f', relError);
printf('\n\n');

%1.4.3A
printf('1.4.3A \n');
x = 2.279;
x2 = chip(1,4,x*x);
x3 = chip(1,4,x*x2);
x4 = chip(1,4,x*x3);
x5 = chip(1,4,x*x4);

poly1 = chip(1,4,chip(1,4,1.013*x5));
poly2 = chip(1,4,chip(1,4,-5.262*x3));
poly3 = chip(1,4,chip(1,4,-0.01732*x2));
poly4 = chip(1,4,chip(1,4,0.8389*x));

kingpoly1 = chip(1,4,chip(1,4,poly1 + poly2));
kingpoly2 = chip(1,4,chip(1,4,poly3 + poly4));

godpoly1 = chip(1,4,chip(1,4, kingpoly1 + kingpoly2));
godpoly2 = chip(1,4,chip(1,4,godpoly1 - 1.912));

onePoly = chip(1,4,godpoly2);
printf('%f',onePoly);
printf('\n\n');

%1.4.3B
printf('1.4.3B \n');

poly1 = chip(1,4,1.013*x2);
poly1_5 = chip(1,4,poly1 -5.262);
polyOne = chip(1,4,poly1 + poly1_5);
poly2 = chip(1,4,poly1_5 * x);
poly2_5 = chip(1,4, poly2 - 0.01732);
poly3 = chip(1,4,poly2_5 * x);
poly3_5 = chip(1,4, poly3 + 0.8389);
poly4 = chip(1,4,poly3_5 * x);
poly4_5 = chip(1,4, poly4  - 1.912);


printf('%f',poly4_5);
printf('\n\n');

%1.4.3C
printf('1.4.3C \n');
absErrorA = abs(-0.097669 +0.1000)
relErrorA = absErrorA / abs(-0.097669)
absErrorB = abs(-0.1009669 + 0.1010)
relErrorB = absErrorB / abs(-0.1009669)
printf('\n');

%1.4.7
printf('1.4.7 \n');

x = 1.00;
x1 = chip(0,3,1.00);
x2 = chip(0,3,0.25);
x3 = chip(0,3,0.11);
x4 = chip(0,3,0.06);
x5 = chip(0,3,0.04);
x6 = chip(0,3,0.02);
x7 = chip(0,3,0.02);
x8 = chip(0,3,0.01);
x9 = chip(0,3,0.01);
x10 = chip(0,3,0.01);

s1 = chip(0,3,chip(0,3,x1+x2));
s2 = chip(0,3,chip(0,3,x3+x4));
s3 = chip(0,3,chip(0,3,x5+x6));
s4 = chip(0,3,chip(0,3,x7+x8));
s5 = chip(0,3,chip(0,3,x9+x10));
s6 = chip(0,3,chip(0,3,s1 + s2));
s7 = chip(0,3,chip(0,3,s3 + s4));
s8 = chip(0,3,chip(0,3,s6 + s7));
sum1 = chip(0,3,chip(0,3,s8 + s5))

x1 = chip(0,3,x/x);
x2 = chip(0,3,x/4.00);
x3 = chip(0,3,x/9.00);
x4 = chip(0,3,x/16.0);
x5 = chip(0,3,x/25.0);
x6 = chip(0,3,x/36.0);
x7 = chip(0,3,x/49.0);
x8 = chip(0,3,x/64.0);
x9 = chip(0,3,x/81.0);
x10 = chip(0,3,x/100.0);
s1 = chip(0,3,chip(0,3,x10+x9));
s2 = chip(0,3,chip(0,3,x8+x7));
s3 = chip(0,3,chip(0,3,x6+x5));
s4 = chip(0,3,chip(0,3,x4+x3));
s5 = chip(0,3,chip(0,3,x2+x1));
s6 = chip(0,3,chip(0,3,s1 + s2));
s7 = chip(0,3,chip(0,3,s3 + s4));
s8 = chip(0,3,chip(0,3,s6 + s7));
sum2 = chip(0,3,chip(0,3,s8 + s5))
printf('The actual value is 1.5497677, which makes the 2nd method more accurate due to there being less round off error. \n\n');

%A1 Part A
printf('A1 Part A \n');

for(i = [1:15])
  i
  x = (10)^-i;
  equation =  sqrt(1 - (x)^2) - sqrt(1 + (x)^2)
  printf('\n'); 
endfor

printf('\n');
  
printf('When it''s 10^-9, that''s when you get the zero but with single precision, then it''s 10^-4.\n\n');


%A1 Part B
printf('A1 Part B \n');

for(i = [1:100])
  i
  x = single((10)^-i);
  equation =  2+ (2*(x^2)) - sqrt(2)
  printf('\n'); 
endfor

printf('There isn''t any number to make this value zero.\n\n');
