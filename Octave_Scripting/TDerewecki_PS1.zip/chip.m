function [res] = chip(x,rnd,t)
% This program is used to round or chop a number x to a specific 
% number t % of digits.

n = rows(x);
m = columns(x);

for( i=[1:n] )
for( j=[1:m] )

s = x(i,j);
 
if( s == 0 )
  w = 0;
else
  ee = fix(log10(abs(s)));
  if( abs(s) > 1 )
    ee = ee + 1;
  end
  if( rnd == 1 )
    w = round(s*(10^(t-ee)))*(10^(ee-t));
  else
    w = fix(s*(10^(t-ee)))*(10^(ee-t));
  end
end

x(i,j) = w;

endfor
endfor

res = x;

endfunction