f = inline('x^3 - 2*x^2 -5');
x(1)= 1;
x(2)= 4;
n = 10^-3;
iteration = 0;
 
for i=3:1000
   x(i) = x(i-1) - (f(x(i-1)))*((x(i-1) - x(i-2))/(f(x(i-1)) - f(x(i-2))));
    iteration=iteration+1;
    if abs((x(i)-x(i-1))/x(i))*100 < n
        root=x(i)
        iteration=iteration
        break
    end
end