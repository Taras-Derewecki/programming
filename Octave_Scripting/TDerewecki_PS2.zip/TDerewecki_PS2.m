% Taras Derewecki
% CMPSC 455
% Problem Set 2

%2.2:
%  2, 4, 9, 11

%2.3:
% 3, 8, 9

%2.4:
% 2, 3, 7a, 9 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.2.2A
printf('2.2.2A\n');

N=2;

%Desired tolerance for stopping condition
tol = 10^-6;

%Function
f = inline('(3*(x + 1)*(x - 0.5)*(x - 1))');

%Estimated interval
a = -2;
b = 1.5;

i = 0;
p = (a + b) / 2

while(i < N)    %iterate at most N times
if(f(p) == 0)   %leave the while loop if we find the root exactly
  i = N;
  printf("Root found exactly. That was lucky! \n")
else          %if we didn't find the root, compare to the sign of "a"
  if(sign(f(p)) * sign(f(a)) > 0)
    a = p;    %adjust "a" to the midpoint of the last interval
  else
    b = p;    %adjust "b" to the midpoint of the last interval
  endif
  oldp = p;   %store the last value of p before we reassign it
  p = (a + b) / 2
  if(abs(p-oldp) < tol)  %check if the tolerance is achieved
    i = N;                 %if so, exit the loop
    printf("Estimate is accurate witin the tolerance. \n")
  endif
  i = i + 1;
  if(i == N)
    printf("Reached max iterations without reaching tolerance goal. \n")
  endif
endif
endwhile

result = p
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.2.2B
printf('2.2.2B\n');

N = 2;

%Desired tolerance for stopping condition
tol = 10^-7;

%Function
f = inline('(3*(x + 1)*(x - 0.5)*(x - 1))');

%Estimated interval
a = -1.25;
b = 2.5;

i = 0;
p = (a + b) / 2

while(i < N)    %iterate at most N times
if(f(p) == 0)   %leave the while loop if we find the root exactly
  i = N;
  printf("Root found exactly. That was lucky! \n")
else          %if we didn't find the root, compare to the sign of "a"
  if(sign(f(p)) * sign(f(a)) > 0)
    a = p;    %adjust "a" to the midpoint of the last interval
  else
    b = p;    %adjust "b" to the midpoint of the last interval
  endif
  oldp = p;   %store the last value of p before we reassign it
  p = (a + b) / 2
  if(abs(p-oldp) < tol)  %check if the tolerance is achieved
    i = N;                 %if so, exit the loop
    printf("Estimate is accurate witin the tolerance. \n")
  endif
  i = i + 1;
  if(i == N)
    printf("Reached max iterations without reaching tolerance goal. \n")
  endif
endif
endwhile

result = p
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.2.4A
printf('2.2.4A\n');

N = 6;

%Desired tolerance for stopping condition
tol = 10^-2;

%Function
f = inline('(x^4) - (2 * x^3) - (4 * x^2) + (4 * x) + 4');
%f = inline('4 + (x * 4 + (x * 2 - (x * 2 - (x))))');

%Estimated interval
a = -2;
b = -1;

i = 0;
p = (a + b) / 2

while(i < N)    %iterate at most N times
if(f(p) == 0)   %leave the while loop if we find the root exactly
  i = N;
  printf("Root found exactly. That was lucky! \n")
else          %if we didn't find the root, compare to the sign of "a"
  if(sign(f(p)) * sign(f(a)) > 0)
    a = p;    %adjust "a" to the midpoint of the last interval
  else
    b = p;    %adjust "b" to the midpoint of the last interval
  endif
  oldp = p;   %store the last value of p before we reassign it
  p = (a + b) / 2
  if(abs(p-oldp) < tol)  %check if the tolerance is achieved
    i = N;                 %if so, exit the loop
    printf("Estimate is accurate witin the tolerance. \n")
  endif
  i = i + 1;
  if(i == N)
    printf("Reached max iterations without reaching tolerance goal. \n")
  endif
endif
endwhile

result = p
printf('\n\n');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.2.4B
printf('2.2.4B\n');

N = 6;

%Desired tolerance for stopping condition
tol = 10^-2;

%Function
f = inline('(x^4) - (2 * x^3) - (4 * x^2) + (4 * x) + 4');

%Estimated interval
a = 0;
b = 2;

i = 0;
p = (a + b) / 2

while(i < N)    %iterate at most N times
if(f(p) == 0)   %leave the while loop if we find the root exactly
  i = N;
  printf("Root found exactly. That was lucky! \n")
else          %if we didn't find the root, compare to the sign of "a"
  if(sign(f(p)) * sign(f(a)) > 0)
    a = p;    %adjust "a" to the midpoint of the last interval
  else
    b = p;    %adjust "b" to the midpoint of the last interval
  endif
  oldp = p;   %store the last value of p before we reassign it
  p = (a + b) / 2
  if(abs(p-oldp) < tol)  %check if the tolerance is achieved
    i = N;                 %if so, exit the loop
    printf("Estimate is accurate witin the tolerance. \n")
  endif
  i = i + 1;
  if(i == N)
    printf("Reached max iterations without reaching tolerance goal. \n")
  endif
endif
endwhile

result = p
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.2.4C
printf('2.2.4C\n');

N = 6;

%Desired tolerance for stopping condition
tol = 10^-2;

%Function
f = inline('(x^4) - (2 * x^3) - (4 * x^2) + (4 * x) + 4');

%Estimated interval
a = 2;
b = 3;

i = 0;
p = (a + b) / 2

while(i < N)    %iterate at most N times
if(f(p) == 0)   %leave the while loop if we find the root exactly
  i = N;
  printf("Root found exactly. That was lucky! \n")
else          %if we didn't find the root, compare to the sign of "a"
  if(sign(f(p)) * sign(f(a)) > 0)
    a = p;    %adjust "a" to the midpoint of the last interval
  else
    b = p;    %adjust "b" to the midpoint of the last interval
  endif
  oldp = p;   %store the last value of p before we reassign it
  p = (a + b) / 2
  if(abs(p-oldp) < tol)  %check if the tolerance is achieved
    i = N;                 %if so, exit the loop
    printf("Estimate is accurate witin the tolerance. \n")
  endif
  i = i + 1;
  if(i == N)
    printf("Reached max iterations without reaching tolerance goal. \n")
  endif
endif
endwhile

result = p
printf('\n\n');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.2.4D
printf('2.2.4D\n');

N = 6;

%Desired tolerance for stopping condition
tol = 10^-2;

%Function
f = inline('(x^4) - (2 * x^3) - (4 * x^2) + (4 * x) + 4');

%Estimated interval
a = -1;
b = 0;

i = 0;
p = (a + b) / 2

while(i < N)    %iterate at most N times
if(f(p) == 0)   %leave the while loop if we find the root exactly
  i = N;
  printf("Root found exactly. That was lucky! \n")
else          %if we didn't find the root, compare to the sign of "a"
  if(sign(f(p)) * sign(f(a)) > 0)
    a = p;    %adjust "a" to the midpoint of the last interval
  else
    b = p;    %adjust "b" to the midpoint of the last interval
  endif
  oldp = p;   %store the last value of p before we reassign it
  p = (a + b) / 2
  if(abs(p-oldp) < tol)  %check if the tolerance is achieved
    i = N;                 %if so, exit the loop
    printf("Estimate is accurate witin the tolerance. \n")
  endif
  i = i + 1;
  if(i == N)
    printf("Reached max iterations without reaching tolerance goal. \n")
  endif
endif
endwhile

result = p
printf('\n\n');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.2.9
printf('2.2.9\n');

N = 12;

%Desired tolerance for stopping condition
tol = 10^-4;

%Function
f = inline('x^2 - 3');

%Estimated interval
a = 1.5;
b = 2;

i = 0;
p = (a + b) / 2

while(i < N)    %iterate at most N times
if(f(p) == 0)   %leave the while loop if we find the root exactly
  i = N;
  printf("Root found exactly. That was lucky! \n")
else          %if we didn't find the root, compare to the sign of "a"
  if(sign(f(p)) * sign(f(a)) > 0)
    a = p;    %adjust "a" to the midpoint of the last interval
  else
    b = p;    %adjust "b" to the midpoint of the last interval
  endif
  oldp = p;   %store the last value of p before we reassign it
  p = (a + b) / 2
  if(abs(p-oldp) < tol)  %check if the tolerance is achieved
    i = N;                 %if so, exit the loop
    printf("Estimate is accurate witin the tolerance. \n")
  endif
  i = i + 1;
  if(i == N)
    printf("Reached max iterations without reaching tolerance goal. \n")
  endif
endif
endwhile

result = p
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.2.11
printf('2.2.11\n');

N = 12;

%Desired tolerance for stopping condition
tol = 10^-3;

%Function
f = inline('x^3 + x - 4');

%Estimated interval
a = 1;
b = 4;

i = 0;
p = (a + b) / 2

while(i < N)    %iterate at most N times
if(f(p) == 0)   %leave the while loop if we find the root exactly
  i = N;
  printf("Root found exactly. That was lucky! \n")
else          %if we didn't find the root, compare to the sign of "a"
  if(sign(f(p)) * sign(f(a)) > 0)
    a = p;    %adjust "a" to the midpoint of the last interval
  else
    b = p;    %adjust "b" to the midpoint of the last interval
  endif
  oldp = p;   %store the last value of p before we reassign it
  p = (a + b) / 2
  if(abs(p-oldp) < tol)  %check if the tolerance is achieved
    i = N;                 %if so, exit the loop
    printf("Estimate is accurate witin the tolerance. \n")
  endif
  i = i + 1;
  if(i == N)
    printf("Reached max iterations without reaching tolerance goal. \n")
  endif
endif
endwhile

result = p
printf('\n\n');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.3.3A
printf('2.3.3A\n');

f = inline('x^3 - 2*x^2 -5');
x(1)= 1;
x(2)= 4;
n = 10^-4;
iteration = 0;
 
for i = 3:1000
   x(i) = x(i-1) - (f(x(i-1)))*((x(i-1) - x(i-2))/(f(x(i-1)) - f(x(i-2))));
    iteration=iteration+1;
    if abs((x(i)-x(i-1))/x(i))*100 < n
        root=x(i)
        iteration=iteration
        break
    end
end
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.3.3B
printf('2.3.3B\n');

f = inline('x^3 + 3*x^2 - 1');
x(1)= -3;
x(2)= -2;
n = 10^-4;
iteration = 0;
 
for i = 3:1000
   x(i) = x(i-1) - (f(x(i-1)))*((x(i-1) - x(i-2))/(f(x(i-1)) - f(x(i-2))));
    iteration=iteration+1;
    if abs((x(i)-x(i-1))/x(i))*100 < n
        root=x(i)
        iteration=iteration
        break
    end
end
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.3.3C
printf('2.3.3C\n');

f = inline('x - cos(x)');
x(1)= 0;
x(2)= (pi/2);
n = 10^-4;
iteration = 0;
 
for i = 3:1000
   x(i) = x(i-1) - (f(x(i-1)))*((x(i-1) - x(i-2))/(f(x(i-1)) - f(x(i-2))));
    iteration=iteration+1;
    if abs((x(i)-x(i-1))/x(i))*100 < n
        root=x(i)
        iteration=iteration
        break
    end
end
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.3.3D
printf('2.3.3D\n');

f = inline('x - 0.8 - (0.2*sin(x))');
x(1)= 0;
x(2)= (pi/2);
n = 10^-4;
iteration = 0;
 
for i = 3:1000
   x(i) = x(i-1) - (f(x(i-1)))*((x(i-1) - x(i-2))/(f(x(i-1)) - f(x(i-2))));
    iteration=iteration+1;
    if abs((x(i)-x(i-1))/x(i))*100 < n
        root=x(i)
        iteration=iteration
        break
    end
end
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.3.8
printf('2.3.8\n');

f = inline('x^2 + 10*cos(x)');
x(1)= 0;
x(2)= 3;
n = 10^-5;
iteration = 0;
 
for i = 3:1000
   x(i) = x(i-1) - (f(x(i-1)))*((x(i-1) - x(i-2))/(f(x(i-1)) - f(x(i-2))));
    iteration=iteration+1;
    if abs((x(i)-x(i-1))/x(i))*100 < n
        root=x(i)
        iteration=iteration
        break
    end
end
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.3.9
printf('2.3.9\n');

f = inline('x^2 -3');
x(1)= 1;
x(2)= 2;
n = 10^-4;
iteration = 0;
 
for i = 3:1000
   x(i) = x(i-1) - (f(x(i-1)))*((x(i-1) - x(i-2))/(f(x(i-1)) - f(x(i-2))));
    iteration=iteration+1;
    if abs((x(i)-x(i-1))/x(i))*100 < n
        root=x(i)
        iteration=iteration
        break
    end
end

printf('It took the Secant Method 8 less iterations than what the bisection method took to arrive at the final answer.\n');
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.4.2
printf('2.4.2\n');

%Max number of iterations N
N = 2;

%Desired tolerance for stopping condition
tol = 10^-200

%To numerically solve f(x)=0, specify f(x) and the derivative g(x)=f'(x)
f = inline('-x^3 - cos(x)');
g = inline('(-3 * (x)^2) + sin(x)');

%Start with an intial guess
p = -1;

%Newton's Method Algorithm
i = 0;
while(i<N)
  if( g(p)==0 )
    printf( "Newton's Method failed, derivative is zero at p=%d on iteration i=%d", p, i )
    i=N;
  else
    q = p;
    p = p - f(p)/g(p);
    p
    if( abs(p-q) < tol )
      printf( "Estimated solution, tolerance reached after i=%d iterations. \n", i)
      p
      i=N;
    endif
  endif
  i=i+1;
  if( i==N )
    printf( "Failed to converge after %d iterations", N )
  endif
endwhile
printf('\np2 is -0.86568, and p0 cannot be used because -3(0)^2 + sin(0) is 0, so it cannot be used. \n');
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.4.3A
printf('2.4.3A\n');

%Max number of iterations N
N = 5;

%Desired tolerance for stopping condition
tol=10^-4;

%To numerically solve f(x)=0, specify f(x) and the derivative g(x)=f'(x)
f = inline('x^3 - (2*(x)^2) - 5');
g = inline('(3*(x)^2) - (4*x)');

%Start with an intial guess
p = 1;

%Newton's Method Algorithm
i = 0;
while(i<N)
  if( g(p)==0 )
    printf( "Newton's Method failed, derivative is zero at p=%d on iteration i=%d", p, i )
    i=N;
  else
    q = p;
    p = p - f(p)/g(p);
    p
    if( abs(p-q) < tol )
      printf( "Estimated solution, tolerance reached after i=%d iterations. \n", i)
      p
      i=N;
    endif
  endif
  i=i+1;
  if( i==N )
    printf( "Failed to converge after %d iterations", N )
  endif
endwhile
printf('\nUsing 1 would result in the integer 5 which is not an element of [1,4], using 4 now... \n');
printf('\n');

%Max number of iterations N
N = 5;

%Desired tolerance for stopping condition
tol=10^-4;

%To numerically solve f(x)=0, specify f(x) and the derivative g(x)=f'(x)
f = inline('x^3 - (2*(x)^2) - 5');
g = inline('(3*(x)^2) - (4*x)');

%Start with an intial guess
p = 4;

%Newton's Method Algorithm
i = 0;
while(i<N)
  if( g(p)==0 )
    printf( "Newton's Method failed, derivative is zero at p=%d on iteration i=%d", p, i )
    i=N;
  else
    q = p;
    p = p - f(p)/g(p);
    p
    if( abs(p-q) < tol )
      printf( "Estimated solution, tolerance reached after i=%d iterations. \n", i)
      p
      i=N;
    endif
  endif
  i=i+1;
  if( i==N )
    printf( "Failed to converge after %d iterations", N )
  endif
endwhile
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.4.3B
printf('2.4.3B\n');

%Max number of iterations N
N = 28;

%Desired tolerance for stopping condition
tol=10^-4;

%To numerically solve f(x)=0, specify f(x) and the derivative g(x)=f'(x)
f = inline('x^3 + (3*(x)^2) - 1');
g = inline('(3*(x)^2) - (6*x)');

%Start with an intial guess
p = -3;

%Newton's Method Algorithm
i = 0;
while(i<N)
  if( g(p)==0 )
    printf( "Newton's Method failed, derivative is zero at p=%d on iteration i=%d", p, i )
    i=N;
  else
    q = p;
    p = p - f(p)/g(p);
    p
    if( abs(p-q) < tol )
      printf( "Estimated solution, tolerance reached after i=%d iterations. \n", i)
      p
      i=N;
    endif
  endif
  i=i+1;
  if( i==N )
    printf( "Failed to converge after %d iterations", N )
  endif
endwhile
printf('\n\n');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.4.3C
printf('2.4.3C\n');

%Max number of iterations N
N = 28;

%Desired tolerance for stopping condition
tol=10^-4;

%To numerically solve f(x)=0, specify f(x) and the derivative g(x)=f'(x)
f = inline('x - cos(x)');
g = inline('1 + sin(x)');

%Start with an intial guess
p = (pi/2);
printf('using 0 brings a value of 1 vs using (pi/2) which brings a value of 0.8, which is closer to zero... using (pi/2).');

%Newton's Method Algorithm
i = 0;
while(i<N)
  if( g(p)==0 )
    printf( "Newton's Method failed, derivative is zero at p=%d on iteration i=%d", p, i )
    i=N;
  else
    q = p;
    p = p - f(p)/g(p);
    p
    if( abs(p-q) < tol )
      printf( "Estimated solution, tolerance reached after i=%d iterations. \n", i)
      p
      i=N;
    endif
  endif
  i=i+1;
  if( i==N )
    printf( "Failed to converge after %d iterations", N )
  endif
endwhile
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.4.3D
printf('2.4.3D\n');

%Max number of iterations N
N = 28;

%Desired tolerance for stopping condition
tol=10^-4;

%To numerically solve f(x)=0, specify f(x) and the derivative g(x)=f'(x)
f = inline('x - 0.8 - (0.2*sin(x))');
g = inline('1 - (0.2*sin(x))');

%Start with an intial guess
p = 0;

%Newton's Method Algorithm
i = 0;
while(i<N)
  if( g(p)==0 )
    printf( "Newton's Method failed, derivative is zero at p=%d on iteration i=%d", p, i )
    i=N;
  else
    q = p;
    p = p - f(p)/g(p);
    p
    if( abs(p-q) < tol )
      printf( "Estimated solution, tolerance reached after i=%d iterations. \n", i)
      p
      i=N;
    endif
  endif
  i=i+1;
  if( i==N )
    printf( "Failed to converge after %d iterations", N )
  endif
endwhile
printf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.4.7A
printf('2.4.7A\n');

%Max number of iterations N
N = 100;

%Desired tolerance for stopping condition
tol=10^-5;

%To numerically solve f(x)=0, specify f(x) and the derivative g(x)=f'(x)
f = inline('x^2 - (2*(x*(e^(-x)))) + (e^(-2*x))');
g = inline('2 * x - 2 *(e^(-x) - x * e^(-x)) - 2 * e^(-2*x)');

%Start with an intial guess
p = 0;

%Newton's Method Algorithm
i = 0;
while(i<N)
  if( g(p)==0 )
    printf( "Newton's Method failed, derivative is zero at p=%d on iteration i=%d", p, i )
    i=N;
  else
    q = p;
    p = p - f(p)/g(p);
    p
    if( abs(p-q) < tol )
      printf( "Estimated solution, tolerance reached after i=%d iterations. \n", i)
      p
      i=N;
    endif
  endif
  i=i+1;
  if( i==N )
    printf( "Failed to converge after %d iterations", N )
  endif
endwhile
printf('\n\n');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%2.4.9
printf('2.4.9\n');

%Max number of iterations N
N = 100;

%Desired tolerance for stopping condition
tol=10^-4;

%To numerically solve f(x)=0, specify f(x) and the derivative g(x)=f'(x)
f = inline('x^2 - 3');
g = inline('(2*x)');

%Start with an intial guess
p = 1.5;

%Newton's Method Algorithm
i = 0;
while(i<N)
  if( g(p)==0 )
    printf( "Newton's Method failed, derivative is zero at p=%d on iteration i=%d", p, i )
    i=N;
  else
    q = p;
    p = p - f(p)/g(p);
    p
    if( abs(p-q) < tol )
      printf( "Estimated solution, tolerance reached after i=%d iterations. \n", i)
      p
      i=N;
    endif
  endif
  i=i+1;
  if( i==N )
    printf( "Failed to converge after %d iterations", N )
  endif
endwhile
printf('It took Newton''s Method 3 less iterations than what the Secant Method took to arrive at the final answer.\n');
printf('\n\n');