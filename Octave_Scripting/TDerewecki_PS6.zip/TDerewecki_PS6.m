% CMPSC 455
% Dr. Justin Keller
% Problem Set 1

%----------------------------------------------------------------

% Problems:
%   Page 431 - 432:
%     1A, 1C, 3A, 5B

%   Page 419-420:
%     3A, 3D, 4A

%----------------------------------------------------------------
clear;
format long;

%source("Gauss.m");

%-------------------------------------------------------------------------------
%   Page 431 - 432: 1A

printf('Page 431 - 432: 1A \n');

%function to minimize
f = inline('(4*x^2-20*x+0.25*y^2+8)^2+(0.5*x*y^2+2*x-5*y+8)^2','x','y')

%calculate the partial derivatives
fx = inline('2*(4*x^2-20*x+0.25*y^2+8)*(8*x-20)+2*(0.5*x*y^2+2*x-5*y+8)*(0.5*y^2+2)','x','y')
fy = inline('2*(4*x^2-20*x+0.25*y^2+8)*(0.5*y)+2*(0.5*x*y^2+2*x-5*y+8)*(x*y-5)','x','y')

%form the gradient
grad = inline('[fx(x,y),fy(x,y)]','x','y');

%start with an initial guess
p = [0,0]
%tolerance of estimate (1eN = 1*10^N)
tol = 0.05

%evaluate the function a small distance away
g = inline('f( x - a*grad(x,y)(1) , y - a*grad(x,y)(2) )','x','y','a')

%find the best value of 'a' and use it to get the next point
function [newp] = newpoint(q,f,g,grad)

  %set the values of a1,a2,a3
  a3 = 1/norm(grad(q(1),q(2)));
  while( g(q(1),q(2),a3) >= f(q(1),q(2)) )
    a3 = a3/2;
  endwhile
  a2 = a3/2;
  a1 = 0;

  %interpolate a1,a2,a3 and g(a1),g(a2),g(a3)
  %with a parabola, then find the vertex
  y1 = g(q(1),q(2),a1);
  y2 = g(q(1),q(2),a2);
  y3 = g(q(1),q(2),a3);

  g1 = divdif([a1,a2,a3],[y1,y2,y3],0)(1);
  h1 = divdif([a1,a2,a3],[y1,y2,y3],1)(1);
  h3 = divdif([a1,a2,a3],[y1,y2,y3],2)(1);

  %use the vertex if it's in the interval, otherwise use the endpoint a3
  ahat = min(a3, (a2*h3-h1)/(2*h3) );
  if( h3 < 0 )
    ahat = a3; %if the parabola opens downward use a3
  endif

  %set the new value of p
  newp(1)= q(1) - ahat*grad(q(1),q(2))(1);
  newp(2)= q(2) - ahat*grad(q(1),q(2))(2);  
endfunction

while( norm( newpoint(p,f,g,grad) - p, inf ) > tol )
  p = newpoint(p,f,g,grad) 
endwhile

p = newpoint(p,f,g,grad)

printf('\n');


%-------------------------------------------------------------------------------


%-------------------------------------------------------------------------------
%   Page 431 - 432: 1C

printf('Page 431 - 432: 1C \n');

%function to minimize
f = inline('(log(x^2 + y^2) - sin(x*y) - log(2)-log(pi))^2 + (e^(x-y)+cos(x*y))^2','x','y')

%calculate the partial derivatives
fx = inline('(2*(e^(x-y)+cos(x*y))*(e^(x-y)-y*sin(x*y))) + (2*(log(x^2+ y^2)-sin(x*y)-log(2*pi))*((2*x)/(y^2 + x^2)) - y*cos(x*y))','x','y')
fy = inline('(2*(e^(x-y)+cos(x*y))*(e^(x-y)-x*sin(x*y))) + (2*(log(x^2+ y^2)-sin(x*y)-log(2*pi))*((2*y)/(y^2 + x^2)) - x*cos(x*y))','x','y') 

%form the gradient
grad = inline('[fx(x,y),fy(x,y)]','x','y');

%start with an initial guess
p = [1,2]
%tolerance of estimate (1eN = 1*10^N)
tol = 0.05

%evaluate the function a small distance away
g = inline('f( x - a*grad(x,y)(1) , y - a*grad(x,y)(2) )','x','y','a')

%find the best value of 'a' and use it to get the next point
function [newp] = newpoint(q,f,g,grad)

  %set the values of a1,a2,a3
  a3 = 1/norm(grad(q(1),q(2)));
  while( g(q(1),q(2),a3) >= f(q(1),q(2)) )
    a3 = a3/2;
  endwhile
  a2 = a3/2;
  a1 = 0;

  %interpolate a1,a2,a3 and g(a1),g(a2),g(a3)
  %with a parabola, then find the vertex
  y1 = g(q(1),q(2),a1);
  y2 = g(q(1),q(2),a2);
  y3 = g(q(1),q(2),a3);

  g1 = divdif([a1,a2,a3],[y1,y2,y3],0)(1);
  h1 = divdif([a1,a2,a3],[y1,y2,y3],1)(1);
  h3 = divdif([a1,a2,a3],[y1,y2,y3],2)(1);

  %use the vertex if it's in the interval, otherwise use the endpoint a3
  ahat = min(a3, (a2*h3-h1)/(2*h3) );
  if( h3 < 0 )
    ahat = a3; %if the parabola opens downward use a3
  endif

  %set the new value of p
  newp(1)= q(1) - ahat*grad(q(1),q(2))(1);
  newp(2)= q(2) - ahat*grad(q(1),q(2))(2);  
endfunction

while( norm( newpoint(p,f,g,grad) - p, inf ) > tol )
  p = newpoint(p,f,g,grad) 
endwhile

p = newpoint(p,f,g,grad)

printf('\n');
%-------------------------------------------------------------------------------


%-------------------------------------------------------------------------------
%   Page 431 - 432: 3A

printf('Page 431 - 432: 3A \n');

%function to minimize
f = inline('((15*x) + (y^2) -(4*z) -13)^2+(x^2 +10*y -z -11)^2 + (y^3 - 25*z +22)^2','x','y','z')

%calculate the partial derivatives
fx = inline('30*(15*x +y^2 - 4*z - 13)+4*x*(x^2 +10*y-z-11) + 0','x','y','z')
fy = inline('4*y*(15*x +y^2 - 4*z - 13)+20*(x^2 +10*y-z-11) + 6*(y^2)*(y^3 - 25*z +22)','x','y','z')
fz = inline('-8*(15*x +y^2 - 4*z - 13)+-2*(x^2 +10*y-z-11) + -50*(y^3 - 25*z +22)','x','y','z')

%form the gradient
grad = inline('[fx(x,y,z),fy(x,y,z),fz(x,y,z)]','x','y','z');

%start with an initial guess
p = [1,2,1]
%tolerance of estimate (1eN = 1*10^N)
tol = 0.05

%evaluate the function a small distance away
g = inline('f( x - a*grad(x,y,z)(1) , y - a*grad(x,y,z)(2), z - a*grad(x,y,z)(3) )','x','y','z','a')

%find the best value of 'a' and use it to get the next point
function [newp] = newpoint(q,f,g,grad)

  %set the values of a1,a2,a3
  a3 = 1/norm(grad(q(1),q(2),q(3)));
  while( g(q(1),q(2), q(1),a3) >= f(q(1),q(2),q(3)) )
    a3 = a3/2;
  endwhile
  a2 = a3/2;
  a1 = 0;

  %interpolate a1,a2,a3 and g(a1),g(a2),g(a3)
  %with a parabola, then find the vertex
  y1 = g(q(1),q(2), q(3),a1);
  y2 = g(q(1),q(2),q(3),a2);
  y3 = g(q(1),q(2),q(3),a3);

  g1 = divdif([a1,a2,a3],[y1,y2,y3],0)(1);
  h1 = divdif([a1,a2,a3],[y1,y2,y3],1)(1);
  h3 = divdif([a1,a2,a3],[y1,y2,y3],2)(1);

  %use the vertex if it's in the interval, otherwise use the endpoint a3
  ahat = min(a3, (a2*h3-h1)/(2*h3) );
  if( h3 < 0 )
    ahat = a3; %if the parabola opens downward use a3
  endif

  %set the new value of p
  newp(1)= q(1) - ahat*grad(q(1),q(2),q(3))(1);
  newp(2)= q(2) - ahat*grad(q(1),q(2),q(3))(2);  
  newp(3)= q(3) - ahat*grad(q(1),q(2),q(3))(3); 
endfunction

while( norm( newpoint(p,f,g,grad) - p, inf ) > tol )
  p = newpoint(p,f,g,grad) 
endwhile

p = newpoint(p,f,g,grad)

printf('\n');


%-------------------------------------------------------------------------------


%-------------------------------------------------------------------------------
%   Page 431 - 432: 5B

printf('Page 431 - 432: 5B \n');

%function to minimize
f = inline('100*(x^2 - y)^2 + (1 - x)^2','x','y')

%calculate the partial derivatives
fx = inline('400*x*(x^2 - y)-2*(1-x)','x','y')
fy = inline('-200*(x^2-y)','x','y') 

%form the gradient
grad = inline('[fx(x,y),fy(x,y)]','x','y');

%start with an initial guess
p = [0,0]
%tolerance of estimate (1eN = 1*10^N)
tol = 0.005

%evaluate the function a small distance away
g = inline('f( x - a*grad(x,y)(1) , y - a*grad(x,y)(2) )','x','y','a')

%find the best value of 'a' and use it to get the next point
function [newp] = newpoint(q,f,g,grad)

  %set the values of a1,a2,a3
  a3 = 1/norm(grad(q(1),q(2)));
  while( g(q(1),q(2),a3) >= f(q(1),q(2)) )
    a3 = a3/2;
  endwhile
  a2 = a3/2;
  a1 = 0;

  %interpolate a1,a2,a3 and g(a1),g(a2),g(a3)
  %with a parabola, then find the vertex
  y1 = g(q(1),q(2),a1);
  y2 = g(q(1),q(2),a2);
  y3 = g(q(1),q(2),a3);

  g1 = divdif([a1,a2,a3],[y1,y2,y3],0)(1);
  h1 = divdif([a1,a2,a3],[y1,y2,y3],1)(1);
  h3 = divdif([a1,a2,a3],[y1,y2,y3],2)(1);

  %use the vertex if it's in the interval, otherwise use the endpoint a3
  ahat = min(a3, (a2*h3-h1)/(2*h3) );
  if( h3 < 0 )
    ahat = a3; %if the parabola opens downward use a3
  endif

  %set the new value of p
  newp(1)= q(1) - ahat*grad(q(1),q(2))(1);
  newp(2)= q(2) - ahat*grad(q(1),q(2))(2);  
endfunction

while( norm( newpoint(p,f,g,grad) - p, inf ) > tol )
  p = newpoint(p,f,g,grad) 
endwhile

p = newpoint(p,f,g,grad)

printf('\n');
%-------------------------------------------------------------------------------


%-------------------------------------------------------------------------------
%   Page 419 - 420: 3A

printf('Page 419 - 420: 3A \n');

%source("Gauss.m");

%Define our system of equations (in the form f_i(x,y) = 0)

f1 = inline('(4*x^2-20*x+0.25*y^2+8)','x','y')
f2 = inline('(0.5*x*y^2+2*x-5*y+8)','x','y')

%Vector form
F = inline('[f1(x,y),f2(x,y)]','x','y')

%Calculate the partial derivatives
f1x = inline('8*x - 20','x','y')
f1y = inline('0.5* y','x','y')
f2x = inline('(0.5*y^2+2)','x','y')
f2y = inline('x*y - 5','x','y')

%Define the Jacobian
J = inline('[ f1x(x,y), f1y(x,y); f2x(x,y), f2y(x,y) ]','x','y')

%Initial guess
p = [0,0]

%Tolerance for the final approximation
tol = 1e-5




%A function to swap row i with row j in the matrix A
function [S] = swapRows(A,i,j)
  temp_row = A(j,:);
  A(j,:) = A(i,:);
  A(i,:) = temp_row;
  S = A;
endfunction

%A function to ensure we have a nonzero entry in A(i,i) with row swaps
function [S] = getPivot(A,i)
  S = A;
  n = rows(S); %get the number of rows
  j=i;
  while( A(i,j)==0 && i < n )
    i = i+1;
  endwhile
  if( A(i,j) != 0 )
    S = swapRows(A,i,j);
  else
    printf("Failed to find a nonzero pivot.");
  endif  
endfunction

%A function to clear the entries below the nonzero entry A(i,i)
function [S] = eliminateColumn(A,i)
  S = getPivot(A,i);
  n = rows(S);
  for( k = [i+1:n] )
    S(k,:) = S(k,:) - (S(k,i)/S(i,i))*S(i,:);
  endfor
endfunction

%Use the auxilliary functions above to row-reduce A to upper triangular format
function [S] = rowReduce(A)
  S = A;
  n = rows(S);
  for( i = [1:n-1] )
    S = eliminateColumn(S,i);
  endfor
endfunction

%Solve the system represented by an augmented matrix by back substitution
function [x] = solveLinear(A)
  x = [];   
  S = rowReduce(A);
  n = rows(S);
  x(n) = S(n,n+1)/S(n,n);
  for( i = [n-1:-1:1] )
    s = 0;
    for( j = [i+1:n] )
      s = s + S(i,j)*x(j);
    endfor
    x(i) = (S(i,n+1) - s)/S(i,i);
  endfor
  x = transpose(x);
endfunction






%Apply one iteration of Newton's Method for systems
function [newp] = newpoint(p,J,F)
  AA = J(p(1),p(2));
  AA(:,3) = -F(p(1),p(2));
  y = solveLinear(AA);
  newp = p + transpose(y);
endfunction

%Iterate until the desired tolerance is reached
while( norm( newpoint(p,J,F) - p, inf ) > tol )
  p = newpoint(p,J,F) 
endwhile

p = newpoint(p,f,g,grad)

printf('\n');
%-------------------------------------------------------------------------------


%-------------------------------------------------------------------------------
%   Page 419 - 420: 3D

printf('Page 419 - 420: 3D \n');

%source("Gauss.m");

%Define our system of equations (in the form f_i(x,y) = 0)

f1 = inline('(x^2 + y - 37)','x','y','z')
f2 = inline('(x - y^2 - 5)','x','y','z')
f3 = inline('(x + y + z - 3)','x','y','z')

%Vector form
F = inline('[f1(x,y,z),f2(x,y,z),f3(x,y,z)]','x','y','z')

%Calculate the partial derivatives
f1x = inline('2*x','x','y','z')
f1y = inline('1','x','y','z')
f1z = inline('0','x','y','z')

f2x = inline('1','x','y','z')
f2y = inline('-2*y','x','y','z')
f2z = inline('0','x','y','z')

f3x = inline('1','x','y','z')
f3y = inline('1','x','y','z')
f3z = inline('1','x','y','z')

%Define the Jacobian
J = inline('[ f1x(x,y,z), f1y(x,y,z), f1z(x,y,z); f2x(x,y,z), f2y(x,y,z), f2z(x,y,z); f3x(x,y,z), f3y(x,y,z), f3z(x,y,z) ]','x','y','z')

%Initial guess
p = [0,0,0]

%Tolerance for the final approximation
tol = 1e-5




%A function to swap row i with row j in the matrix A
function [S] = swapRows(A,i,j)
  temp_row = A(j,:);
  A(j,:) = A(i,:);
  A(i,:) = temp_row;
  S = A;
endfunction

%A function to ensure we have a nonzero entry in A(i,i) with row swaps
function [S] = getPivot(A,i)
  S = A;
  n = rows(S); %get the number of rows
  j=i;
  while( A(i,j)==0 && i < n )
    i = i+1;
  endwhile
  if( A(i,j) != 0 )
    S = swapRows(A,i,j);
  else
    printf("Failed to find a nonzero pivot.");
  endif  
endfunction

%A function to clear the entries below the nonzero entry A(i,i)
function [S] = eliminateColumn(A,i)
  S = getPivot(A,i);
  n = rows(S);
  for( k = [i+1:n] )
    S(k,:) = S(k,:) - (S(k,i)/S(i,i))*S(i,:);
  endfor
endfunction

%Use the auxilliary functions above to row-reduce A to upper triangular format
function [S] = rowReduce(A)
  S = A;
  n = rows(S);
  for( i = [1:n-1] )
    S = eliminateColumn(S,i);
  endfor
endfunction

%Solve the system represented by an augmented matrix by back substitution
function [x] = solveLinear(A)
  x = [];   
  S = rowReduce(A);
  n = rows(S);
  x(n) = S(n,n+1)/S(n,n);
  for( i = [n-1:-1:1] )
    s = 0;
    for( j = [i+1:n] )
      s = s + S(i,j)*x(j);
    endfor
    x(i) = (S(i,n+1) - s)/S(i,i);
  endfor
  x = transpose(x);
endfunction






%Apply one iteration of Newton's Method for systems
function [newp] = newpoint(p,J,F)
  AA = J(p(1),p(2),p(3));
  AA(:,4) = -F(p(1),p(2),p(3));
  y = solveLinear(AA);
  newp = p + transpose(y);
endfunction

%Iterate until the desired tolerance is reached
while( norm( newpoint(p,J,F) - p, inf ) > tol )
  p = newpoint(p,J,F) 
endwhile

p = newpoint(p,f,g,grad)

printf('\n');
%-------------------------------------------------------------------------------


%-------------------------------------------------------------------------------
%   Page 419 - 420: 4A

printf('Page 419 - 420: 4A \n');

%source("Gauss.m");

%Define our system of equations (in the form f_i(x,y) = 0)

f1 = inline('3*x^2 - y^2','x','y')
f2 = inline('(3*x*y^2 - x^3 - 1)','x','y')

%Vector form
F = inline('[f1(x,y),f2(x,y)]','x','y')

%Calculate the partial derivatives
f1x = inline('6*x','x','y')
f1y = inline('-2*y','x','y')
f2x = inline('3*y^2 - 3*x','x','y')
f2y = inline('6*x*y','x','y')

%Define the Jacobian
J = inline('[ f1x(x,y), f1y(x,y); f2x(x,y), f2y(x,y) ]','x','y')

%Initial guess
p = [1,1]

%Tolerance for the final approximation
tol = 0.000001




%A function to swap row i with row j in the matrix A
function [S] = swapRows(A,i,j)
  temp_row = A(j,:);
  A(j,:) = A(i,:);
  A(i,:) = temp_row;
  S = A;
endfunction

%A function to ensure we have a nonzero entry in A(i,i) with row swaps
function [S] = getPivot(A,i)
  S = A;
  n = rows(S); %get the number of rows
  j=i;
  while( A(i,j)==0 && i < n )
    i = i+1;
  endwhile
  if( A(i,j) != 0 )
    S = swapRows(A,i,j);
  else
    printf("Failed to find a nonzero pivot.");
  endif  
endfunction

%A function to clear the entries below the nonzero entry A(i,i)
function [S] = eliminateColumn(A,i)
  S = getPivot(A,i);
  n = rows(S);
  for( k = [i+1:n] )
    S(k,:) = S(k,:) - (S(k,i)/S(i,i))*S(i,:);
  endfor
endfunction

%Use the auxilliary functions above to row-reduce A to upper triangular format
function [S] = rowReduce(A)
  S = A;
  n = rows(S);
  for( i = [1:n-1] )
    S = eliminateColumn(S,i);
  endfor
endfunction

%Solve the system represented by an augmented matrix by back substitution
function [x] = solveLinear(A)
  x = [];   
  S = rowReduce(A);
  n = rows(S);
  x(n) = S(n,n+1)/S(n,n);
  for( i = [n-1:-1:1] )
    s = 0;
    for( j = [i+1:n] )
      s = s + S(i,j)*x(j);
    endfor
    x(i) = (S(i,n+1) - s)/S(i,i);
  endfor
  x = transpose(x);
endfunction






%Apply one iteration of Newton's Method for systems
function [newp] = newpoint(p,J,F)
  AA = J(p(1),p(2));
  AA(:,3) = -F(p(1),p(2));
  y = solveLinear(AA);
  newp = p + transpose(y);
endfunction

%Iterate until the desired tolerance is reached
while( norm( newpoint(p,J,F) - p, inf ) > tol )
  p = newpoint(p,J,F) 
endwhile
p = newpoint(p,f,g,grad)

printf('\n');