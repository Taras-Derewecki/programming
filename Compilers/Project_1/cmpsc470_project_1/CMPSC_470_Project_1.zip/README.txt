compile: java *.java
run: java Main test.txt 


test.txt is a text file that you want to the program to read.