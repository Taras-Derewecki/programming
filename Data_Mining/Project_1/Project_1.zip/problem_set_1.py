import random

# to count number of pairs
def number_of_pairs(item_set):
	count = 0
	for i in range(0,10000):
		for j in range(i+1,10000):
			if(item_set[i] == item_set[j]):
				count = count+1
	return count

#to randomly select 3 unique items
def select_three_items():
	x = random.randint(1,200)
	y = random.randint(1,200)
	z = random.randint(1,200)
	while(y==x):
		y = random.randint(1,200)
	while(z==x or y==z):
		z = random.randint(1,200)

	return [x,y,z]

# main code execution begins here
random.seed(1)
total = 0
#run loop 100 times to simulate the scenario 100 times
for iters in range(0,100):
	#array of people
	people = []
	for i in range(0,10000):
		people.append(i)

	item_set_arr = []

	#array of items bought by people
	for p in people:
		item_set = select_three_items()
		item_set_arr.append(item_set)

	#finding number of pairs that are same
	n = number_of_pairs(item_set_arr)
	total = total = n
	#printing result of each iteration
	print ("Iteration " + str(iters+1) + "\nExpected number of pairs identified as terrorists = " + str(n) + "\n")

#finding average pairs of people identified as terrorists
avg = total/100
print("Average number of pairs identified as terrorists = " + str(avg))